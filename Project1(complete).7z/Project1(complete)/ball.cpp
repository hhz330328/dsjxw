#include "Ball.h"
#include"list.h"
#include<math.h>
#include<d2d1.h>
#include<stack>
#define R 1.7
void Ball::boommm()
{

    Link_Node<collisionball>* cur = collisionlist.getlinkhead();
    while (cur->rlink != nullptr)
    {
        cur->rlink->data.A->collision(cur->rlink->data.B, 1);
        cur = cur->rlink;
        collnumber++;
    }
    collisionlist.clear();
}

bool Ball::is_collision(Ball* b)
{
    if (((position.getx() + 2 * R < b->position.getx() + 2 * R) && (position.getx() + 2 * R > b->position.getx() - 2 * R) && (position.gety() + 2 * R < b->position.gety() + 2 * R) && (position.gety() + 2 * R > b->position.gety() - 2 * R)) || ((position.getx() - 2 * R < b->position.getx() + 2 * R) && (position.getx() - 2 * R > b->position.getx() - 2 * R) && (position.gety() - 2 * R < b->position.gety() + 2 * R) && (position.gety() - 2 * R > b->position.gety() - 2 * R)))
    {
        ++collnumber;
        ++totalcollnumber;
        if (((position.getx() + 0.5 * R < b->position.getx() + 0.5 * R) && (position.getx() + 0.5 * R > b->position.getx() - 0.5 * 0.5 * R) && (position.gety() + 0.5 * R < b->position.gety() + 0.5 * R) && (position.gety() + 0.5 * R > b->position.gety() - 0.5 * R)) || ((position.getx() - 0.5 * R < b->position.getx() + 0.5 * R) && (position.getx() - 0.5 * R > b->position.getx() - 0.5 * R) && (position.gety() - 0.5 * R < b->position.gety() + 0.5 * R) && (position.gety() - 0.5 * R > b->position.gety() - 0.5 * R)))
        {
            position.setx(position.getx() + 0.4 * R);
            position.sety(position.gety() + 0.4 * R);
            b->position.setx(b->position.getx() - 0.4 * R);
            b->position.sety(b->position.gety() - 0.4 * R);
        }
        else
        {
            collisionlist.push_back(collisionball(this, b));

        }
        return true;
    }
    return false;
}

void Ball::collision(Ball* b)
{
    Magnitude temp;
    temp = Velocity;
    Velocity = b->Velocity;
    b->Velocity = temp;
}
void Ball::collision(Ball* b, int flag)
{
    if (position.getx() == b->position.getx())
    {
        float temp = Velocity.gety();
        Velocity.sety(b->Velocity.gety());
        b->Velocity.sety(temp);
        return;
    }
    float k = getK(position, b->position);
    Magnitude tempvaq, tempvbq, tempvaf, tempvbf;
    tempvaq.setx((Velocity.getx() + k * Velocity.gety()) / (1 + k * k));
    tempvaq.sety(tempvaq.getx() * k);
    tempvbq.setx((b->Velocity.getx() + k * b->Velocity.gety()) / (1 + k * k));
    tempvbq.sety(tempvbq.getx() * k);
    tempvaf = Velocity - tempvaq;
    tempvbf = b->Velocity - tempvbq;
    Velocity = tempvbq + tempvaf;
    b->Velocity = tempvaq + tempvbf;
    Velocity = tempvbq + tempvaf;
    b->Velocity = tempvaq + tempvbf;
}
point Ball::getposition()
{
    return position;
}

float Ball::getK(point A, point B)
{
    return ((A.gety() - B.gety()) / (A.getx() - B.getx()));
}
float Ball::getvelocityx() {
    return Velocity.getx();

}
float Ball::getvelocityy() {
    return Velocity.gety();
}
Magnitude Ball::getvelocity() {
    return Velocity;
}
Ball::Ball()
{

}

Ball::Ball(float px, float py)
{
    position.setx(px);
    position.sety(py);
}

Ball::Ball(float px, float py, float vx, float vy)
{
    position.setx(px);
    position.sety(py);
    Velocity.set(vx, vy);
}
void Ball::setpos(float x1, float x2) {
    position.setpos(x1, x2);

};
void Ball::setvelocity(float x1, float x2) {
    Velocity.set(x1, x2);

};
void Ball::setvelocity(Magnitude a) {
    Velocity.set(a.getx(), a.gety());
}
void Ball::setmaxspeed(float x1) {
    MaxSpeed = x1;
};

Magnitude Magnitude::operator+(Magnitude B)
{
    Magnitude newv;
    newv.x = this->x + B.x;
    newv.y = this->y + B.y;
    return newv;
}

Magnitude Magnitude::operator-(Magnitude B)
{
    Magnitude newv;
    newv.x = this->x - B.x;
    newv.y = this->y - B.y;
    return newv;
}

float Magnitude::getx()
{
    return x;
}

float Magnitude::gety()
{
    return y;
}

void Magnitude::getmag(float& vx, float& vy)
{
    vx = x;
    vy = y;
}

void Magnitude::set(float vx, float vy)
{
    x = vx;
    y = vy;
}

float point::getx()
{
    return x;
}

float point::gety()
{
    return y;
}

void point::getpos(float& px, float& py)
{
    px = x;
    py = y;
}

void point::setx(float px)
{
    x = px;
}

void point::sety(float py)
{
    y = py;
}

void point::setpos(float px, float py)
{
    x = px;
    y = py;
}

bool point::operator>(point A)
{
    if (x > A.x && y > A.y)
        return true;
    return false;
}

bool point::operator<(point A)
{
    if (x < A.x && y < A.y)
        return true;
    return false;
}
void point::operator+(point A) {
    x = x + A.getx();
    y = y + A.gety();
}
void f_tree::setrootrec(float px1, float py1, float px2, float py2)
{
    root->rec.L_T = point(px1, py1);
    root->rec.R_B = point(px2, py2);
    root->rec.X_line = (py1 + py2) / 2;
    root->rec.Y_line = (px1 + px2) / 2;
}

void f_tree::division(f_tree_node* cur)
{
    cur->child[0] = new f_tree_node;
    cur->child[1] = new f_tree_node;
    cur->child[2] = new f_tree_node;
    cur->child[3] = new f_tree_node;
    for (int i = 0; i < 4; i++)
    {
        cur->child[i]->number = i;
    }
    float px1 = cur->rec.L_T.getx();
    float px2 = cur->rec.R_B.getx();
    float py1 = cur->rec.L_T.gety();
    float py2 = cur->rec.R_B.gety();
    float xline = cur->rec.X_line;
    float yline = cur->rec.Y_line;
    cur->child[0]->rec.L_T.setpos(px1, py1);
    cur->child[0]->rec.R_B.setpos(yline, xline);
    cur->child[1]->rec.L_T.setpos(yline, py1);
    cur->child[1]->rec.R_B.setpos(px2, xline);
    cur->child[2]->rec.L_T.setpos(px1, xline);
    cur->child[2]->rec.R_B.setpos(yline, py2);
    cur->child[3]->rec.L_T.setpos(yline, xline);
    cur->child[3]->rec.R_B.setpos(px2, py2);
    for (int i = 0; i < 4; i++)
    {
        cur->child[i]->rec.X_line = (cur->child[i]->rec.L_T.gety() + cur->child[i]->rec.R_B.gety()) / 2;
        cur->child[i]->rec.Y_line = (cur->child[i]->rec.L_T.getx() + cur->child[i]->rec.R_B.getx()) / 2;
    }
    Link_Node<Ball*>* current = cur->balllist.getlinkhead();
    while (current != nullptr && current->rlink != NULL)
    {
        if (current->rlink->data->getposition().getx() < yline + R && current->rlink->data->getposition().getx() > yline - R)
        {
            current = current->rlink;
            continue;
        }
        if (current->rlink->data->getposition().gety() < xline + R && current->rlink->data->getposition().gety() > xline - R)
        {
            current = current->rlink;
            continue;
        }
        if (current->rlink->data->getposition().getx() >= yline + R)
        {
            if (current->rlink->data->getposition().gety() >= xline + R)
            {
                cur->child[3]->balllist.push_back(current->rlink->data);
                if (cur->child[3]->balllist.getlast() > ball_maxnum && cur->child[3]->child[0] == NULL)
                {
                    division(cur->child[3]);
                }
                Ball* temp = current->rlink->data;
                current = current->rlink->rlink;
                cur->balllist.deldata(temp);
                continue;
            }
            else if (current->rlink->data->getposition().gety() <= xline - R)
            {
                cur->child[1]->balllist.push_back(current->rlink->data);
                if (cur->child[1]->balllist.getlast() > ball_maxnum && cur->child[1]->child[0] == NULL)
                {
                    division(cur->child[1]);
                }
                Ball* temp = current->rlink->data;
                current = current->rlink->rlink;
                cur->balllist.deldata(temp);
                continue;
            }
        }
        else if (current->rlink->data->getposition().getx() <= yline - R)
        {
            if (current->rlink->data->getposition().gety() >= xline + R)
            {
                cur->child[0]->balllist.push_back(current->rlink->data);
                if (cur->child[0]->balllist.getlast() > ball_maxnum && cur->child[0]->child[0] == NULL)
                {
                    division(cur->child[0]);
                }
                Ball* temp = current->rlink->data;
                current = current->rlink->rlink;
                cur->balllist.deldata(temp);
                continue;
            }
            else if (current->rlink->data->getposition().gety() <= xline - R)
            {
                cur->child[2]->balllist.push_back(current->rlink->data);
                if (cur->child[2]->balllist.getlast() > ball_maxnum && cur->child[2]->child[0] == NULL)
                {
                    division(cur->child[2]);
                }
                Ball* temp = current->rlink->data;
                current = current->rlink->rlink;
                cur->balllist.deldata(temp);
                continue;
            }
        }
    }
}

void f_tree::insert(Ball* A)
{

    f_tree_node* current = root;
    while (current->child[0] != NULL)
    {
        if (A->getposition().getx() < current->rec.Y_line + R && A->getposition().getx() > current->rec.Y_line - R)
            break;
        if (A->getposition().gety() < current->rec.X_line + R && A->getposition().gety() > current->rec.X_line - R)
            break;
        if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[3];
            }
            else
            {
                current = current->child[1];
            }
        }
        else
        {
            if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[0];
            }
            else
            {
                current = current->child[2];
            }
        }
    }
    current->balllist.push_back(A);
    if (current->balllist.getlast() > ball_maxnum && current->child[0] == NULL)
    {
        division(current);
    }

}








void f_tree::reinsert(Ball* A, int width, int height)
{
    if (root == nullptr)
    {
        root = new f_tree_node;
        setrootrec(0, 0, width, height);
    }
    f_tree_node* current = root;
    while (current->child[0] != NULL)
    {
        if (A->getposition().getx() < current->rec.Y_line + R && A->getposition().getx() > current->rec.Y_line - R)
            break;
        if (A->getposition().gety() < current->rec.X_line + R && A->getposition().gety() > current->rec.X_line - R)
            break;
        if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[3];
            }
            else
            {
                current = current->child[1];
            }
        }
        else
        {
            if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[0];
            }
            else
            {
                current = current->child[2];
            }
        }
    }
    current->balllist.push_back(A);
    if (current->balllist.getlast() > ball_maxnum && current->child[0] == NULL)
    {
        division(current);
    }
}

void f_tree::check(Ball* A)
{
    f_tree_node* current = root;
    f_tree_node* cur[4] = { nullptr };
    int flag;
    while (current->child[0] != NULL)
    {
        if ((A->getposition().getx() < current->rec.Y_line + R && A->getposition().getx() > current->rec.Y_line - R) && (A->getposition().gety() < current->rec.X_line + R && A->getposition().gety() > current->rec.X_line - R))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
            {
                if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
                {
                    flag = 3;
                }
                else
                {
                    flag = 1;
                }
            }
            else
            {
                if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
                {
                    flag = 0;
                }
                else
                {
                    flag = 2;
                }
            }
            if (pow(A->getposition().getx(), 2) + pow(A->getposition().gety(), 2) < pow(R, 2))
            {
                cur[0] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line - 0.1 * R));
                cur[1] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line - 0.1 * R));
                cur[2] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line + 0.1 * R));
                cur[3] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line + 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            }
            else
            {
                switch (flag)
                {
                case 0:
                    cur[1] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line - 0.1 * R));
                    cur[2] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line + 0.1 * R));
                    cur[flag] = search(A->getposition());
                    break;
                case 1:
                    cur[0] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line - 0.1 * R));
                    cur[3] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line + 0.1 * R));
                    cur[flag] = search(A->getposition());
                    break;
                case 2:
                    cur[0] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line - 0.1 * R));
                    cur[3] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line + 0.1 * R));
                    cur[flag] = search(A->getposition());
                    break;
                case 3:
                    cur[1] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line - 0.1 * R));
                    cur[2] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line + 0.1 * R));
                    cur[flag] = search(A->getposition());
                    break;
                }
                break;
            }
        }
        if ((A->getposition().getx() < current->rec.Y_line + R && A->getposition().getx() > current->rec.Y_line - R))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
            {
                if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
                {
                    flag = 3;
                }
                else
                {
                    flag = 1;
                }
            }
            else
            {
                if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
                {
                    flag = 0;
                }
                else
                {
                    flag = 2;
                }
            }
            switch (flag)
            {
            case 0:
                cur[1] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line - 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            case 1:
                cur[0] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line - 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            case 2:
                cur[3] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line + 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            case 3:
                cur[2] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line + 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            }
            break;
        }
        if ((A->getposition().gety() < current->rec.X_line + R && A->getposition().gety() > current->rec.X_line - R))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
            {
                if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
                {
                    flag = 3;
                }
                else
                {
                    flag = 1;
                }
            }
            else
            {
                if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
                {
                    flag = 0;
                }
                else
                {
                    flag = 2;
                }
            }
            switch (flag)
            {
            case 0:
                cur[2] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line + 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            case 1:
                cur[3] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line + 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            case 2:
                cur[0] = search(point(current->rec.Y_line - 0.1 * R, current->rec.X_line - 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            case 3:
                cur[1] = search(point(current->rec.Y_line + 0.1 * R, current->rec.X_line - 0.1 * R));
                cur[flag] = search(A->getposition());
                break;
            }
            break;
        }
        if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[3];
            }
            else
            {
                current = current->child[1];
            }
        }
        else
        {
            if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[0];
            }
            else
            {
                current = current->child[2];
            }
        }
        cur[0] = current;
    }
    if (current == root)
        cur[0] = current;
    for (int i = 0; i < 4; i++)
    {
        if (cur[i] == nullptr)
            continue;
        Link_Node<Ball*>* currr = cur[i]->balllist.getlinkhead();
        while (currr->rlink != NULL)
        {
            A->is_collision(currr->rlink->data);
            currr = currr->rlink;
        }
    }
}

f_tree_node* f_tree::search(point A)
{
    f_tree_node* current = root;
    while (current->child[0] != NULL)
    {
        if (A > point(current->rec.Y_line, current->rec.L_T.gety()))
        {
            if (A > point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[3];
            }
            else
            {
                current = current->child[1];
            }
        }
        else
        {
            if (A < point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[0];
            }
            else
            {
                current = current->child[2];
            }
        }
    }
    return current;
}

f_tree_node* f_tree::search(Ball* A)
{
    f_tree_node* current = root;
    while (current->child[0] != NULL)
    {
        if (A->getposition().getx() < current->rec.Y_line + R && A->getposition().getx() > current->rec.Y_line - R)
            break;
        if (A->getposition().gety() < current->rec.X_line + R && A->getposition().gety() > current->rec.X_line - R)
            break;
        if (A->getposition() > point(current->rec.Y_line, current->rec.L_T.gety()))
        {
            if (A->getposition() > point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[3];
            }
            else
            {
                current = current->child[1];
            }
        }
        else
        {
            if (A->getposition() < point(current->rec.Y_line, current->rec.X_line))
            {
                current = current->child[0];
            }
            else
            {
                current = current->child[2];
            }
        }
    }
    return current;
}

void f_tree::check()
{
    std::stack<f_tree_node*> leaf;
    f_tree_node* tag = root;
    f_tree_node* cur = root;
    std::stack<f_tree_node*> sta;
    sta.push(root);
    while (!sta.empty())
    {
        if (tag != cur->child[0] && tag != cur->child[1] && tag != cur->child[2] && tag != cur->child[3])
        {
            if (cur->child[0] == NULL)
            {
                leaf.push(cur);
            }
            else
            {
                Link_Node<Ball*>* current = cur->balllist.getlinkhead();
                while (current->rlink != NULL)
                {
                    check(current->rlink->data);
                    current->rlink->data->flag = 1;
                    current = current->rlink;
                }
                tag = cur;
            }
        }
        if (tag == cur && cur->child[0] != NULL)
        {
            cur = cur->child[0];
            sta.push(cur);
            continue;
        }
        if (tag->number == 3 || cur->child[0] == NULL)
        {
            sta.pop();
            tag = cur;
            if (!sta.empty())
                cur = sta.top();
            continue;
        }
        if (tag->number < 3)
        {
            cur = cur->child[tag->number + 1];
            sta.push(cur);
        }
    }
    while (!leaf.empty())
    {
        f_tree_node* ppp = leaf.top();
        Link_Node<Ball*>* current = ppp->balllist.getlinkhead();
        while (current->rlink != NULL)
        {
            check(current->rlink->data);
            current->rlink->data->flag = 1;
            current = current->rlink;
        }
        leaf.pop();
    }
}
