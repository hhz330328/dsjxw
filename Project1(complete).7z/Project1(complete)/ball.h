#pragma once
#include<math.h>
#include<d2d1.h>
#include"list.h"
class Ball;
struct collisionball
{
	Ball* A;
	Ball* B;
	collisionball(Ball* a, Ball* b)
	{
		A = a;
		B = b;
	}
	collisionball()
	{

	}
	bool operator==(collisionball C)
	{
		if (A == C.A && B == C.B)
			return true;
		return false;
	}
};
class Magnitude;
class point;


class Magnitude
{
private:
	float x;
	float y;
public:
	Magnitude(float x1, float x2) {
		x = x1;
		y = x2;
	};
	Magnitude() {
		x = 0;
		y = 0;
	};
	Magnitude operator+(Magnitude B);
	Magnitude operator-(Magnitude B);
	float getx();
	float gety();
	void getmag(float& vx, float& vy);   //��ȡ�ٶȷ���
	void set(float vx, float vy);
	void setx(float vx)
	{
		x = vx;
	}
	void sety(float vy)
	{
		y = vy;
	}
	bool isZero()
	{
		if (fabsf(x) < 0.000001 && fabsf(y) < 0.000001)return true;
		return false;
	}
	float GetModel()
	{
		return (x * x + y * y);
	}
	void VectorToOne()
	{
		float Model = sqrt(GetModel());
		x /= Model;
		y /= Model;
	}
	void operator*(float s)
	{

		this->x = x * s;
		this->y = y * s;

	}

};

class point
{
private:
	float x;
	float y;
public:
	point() {
		x = 0;
		y = 0;
	};
	float getx();
	float gety();
	void getpos(float& px, float& py);
	void setx(float px);
	void sety(float py);
	void setpos(float px, float py);
	bool operator>(point A);    //�жϵ��Ƿ���A������·�
	bool operator<(point A);	//�жϵ��Ƿ���A������Ϸ�
	void operator+(point A);
	point(float x1, float x2)
	{
		x = x1;
		y = x2;
	}
};

struct rect
{
	point L_T;
	point R_B;
	float X_line;
	float Y_line;
};

struct f_tree_node
{
	int number = 0;
	rect rec;
	f_tree_node* child[4] = { NULL };
	Linklist<Ball*> balllist;
	~f_tree_node()
	{
		if (child[0] != NULL)
		{
			delete child[0];
			delete child[1];
			delete child[2];
			delete child[3];
		}		
	}
};
class Ball
{
private:
	point position;
	Magnitude Velocity;
	float MaxSpeed;
public:
	f_tree_node* pos;
	int flag = 0;
	static int collnumber;
	static long long int totalcollnumber;
	static void boommm();   //������ײ�б�������ײ
	static Linklist<collisionball> collisionlist;    //�����⵽�Ļ���ײ��С��
	bool is_collision(Ball* b); //�ж�С���bС���Ƿ����ײ
	void collision(Ball* b);          //С����bС�������ײ
	void collision(Ball* b, int flag);
	point getposition();                      //���С��λ��
	static float getK(point A, point B);     //���б��
	Ball();
	Ball(float x1, float x2);
	Ball(float px, float py, float vx, float vy);
	void setpos(float x1, float x2);
	void setvelocity(float x1, float x2);
	void setvelocity(Magnitude a);
	void setmaxspeed(float x1);
	Magnitude getvelocity();
	float getvelocityx();
	float getvelocityy();
	void Reserve() {
		Velocity.set(-Velocity.getx(), -Velocity.gety());
	};
	virtual void action(float DeltaTime, float width, float height)
	{
		move(DeltaTime);
		if (position.getx() < 0) {
			Reserve();
		};
		if (position.gety() < 0) {
			Reserve();
		};
		if (position.getx() > width) {
			Reserve();
		};
		if (position.gety() > height) {
			Reserve();
		};
	}
	bool IsInside(float width, float height) {
		if (position.getx() < width && position.gety() < height && position.gety() > 0 && position.getx() > 0)
		{
			return TRUE;
		};
		return FALSE;
	};
	void move(float DeltaTime)
	{

		if (Velocity.isZero())
		{
			return;
		}
		else
		{
			position.setx(position.getx() + Velocity.getx() * DeltaTime);
			position.sety(position.gety() + Velocity.gety() * DeltaTime);

		}

	}
};
class f_tree
{
private:
	f_tree_node* root = NULL;
	int height;
	int ball_maxnum;
public:
	f_tree()
	{
		root = new f_tree_node;
	}
	~f_tree()
	{
		delete root;
	}
	void setmax(int max)
	{
		ball_maxnum = max;
	}
	void setrootrec(float px1, float py1, float px2, float py2);
	void division(f_tree_node* cur);    //������ָ��Ĳ���
	void insert(Ball* A);  //�����½���С��
	void reinsert(Ball* A, int width, int height);   //���·���С�����ڽڵ�
	void check(Ball* A);     //���A������Щ����ײ
	f_tree_node* search(point A);  //Ѱ��A�����ڽڵ�
	f_tree_node* search(Ball* A);
	void clear()
	{
		delete root;
		root = nullptr;
	}
	void check();
};

