#include<cmath>
#include<dinput.h>
#include<windows.h>
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#include<d2d1.h>
#pragma comment(lib,"d2d1.lib")
#include<D2d1helper.h>
#include<wincodec.h>
#pragma comment(lib, "Windowscodecs.lib" )
#include<vector>
#include<sstream>
#include<random>
#include"ball.h"
#include"list.h"
#include"omp.h"
#pragma warning(disable:4996)
using namespace std;
int enemy_create_number = 100000;					//һ������С�������
int TotalNumberOfBall = 200000;                    //��Ҫ���ɵ�С���������
int width = 1280; int height = 960;
int realwidth = 8000; int realheight = 8000;
int balltreemax = 50;
bool GameIsRun = true;
HWND hwnd;
int Ball::collnumber = 0;
long long int Ball::totalcollnumber;
Linklist<collisionball> Ball::collisionlist;
HWND CreateMyWindow(HINSTANCE hInstance, WNDPROC WndProc, int nCmdShow)
{
	HWND hwnd;
	WNDCLASSW wc;
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = nullptr;
	wc.hCursor = nullptr;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = nullptr;
	wc.lpszClassName = L"WINDOWS";
	RegisterClassW(&wc);
	hwnd = CreateWindowW(L"WINDOWS", L"TEST", WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, width, height, nullptr, nullptr, hInstance, nullptr);
	if (!hwnd)
	{
		return nullptr;
	}
	else
	{
		//�������ڿͻ�����С
		RECT rcWindow;
		RECT rcClient;
		int borderWidth, borderHeight;
		GetWindowRect(hwnd, &rcWindow);
		GetClientRect(hwnd, &rcClient);
		borderWidth = (rcWindow.right - rcWindow.left)
			- (rcClient.right - rcClient.left);
		borderHeight = (rcWindow.bottom - rcWindow.top)
			- (rcClient.bottom - rcClient.top);
		SetWindowPos(hwnd, 0, CW_USEDEFAULT, 0, borderWidth + width,
			borderHeight + height, SWP_NOMOVE | SWP_NOZORDER);
	}
	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);
	return hwnd;
}

//�������ҵ���gametimer
class GameTimer
{
public:
	GameTimer() :mSecondsPerCount(0.0), mDeltaTime(-1.0), mBaseTime(0),
		mPausedTime(0), mPrevTime(0), mCurrTime(0), mStopped(false)
	{
		__int64 countsPerSec;
		QueryPerformanceFrequency((LARGE_INTEGER*)&countsPerSec);
		mSecondsPerCount = 1.0 / (double)countsPerSec;
	};
	~GameTimer() {};
	float GameTime()const;//in seconds
	float DeltaTime()const//in seconds
	{
		return (float)mDeltaTime;
	}
	void Reset()//����Ϣѭ��֮ǰ����
	{
		__int64 currtime;
		QueryPerformanceCounter((LARGE_INTEGER*)&currtime);
		mBaseTime = currtime;
		mPrevTime = currtime;
		mStopTime = 0;
		mStopped = false;
	}
	void Tick() //ÿ��֡����һ��
	{
		if (mStopped)
		{
			mDeltaTime = 0.0;
			return;
		}
		__int64	currTime;
		QueryPerformanceCounter((LARGE_INTEGER*)&currTime);
		mCurrTime = currTime;
		//������ʱ��
		mDeltaTime = (mCurrTime - mPrevTime) * mSecondsPerCount;
		//Ϊ��һ�μ�����׼��
		mPrevTime = mCurrTime;
		if (mDeltaTime < 0.0)
		{
			mDeltaTime = 0.0;
		}
	}
	float TotalTime()const
	{
		// If we are stopped, do not count the time that has passed since we stopped.
		// Moreover, if we previously already had a pause, the distance 
		// mStopTime - mBaseTime includes paused time, which we do not want to count.
		// To correct this, we can subtract the paused time from mStopTime:  
		//
		//                     |<--paused time-->|
		// ----*---------------*-----------------*------------*------------*------> time
		//  mBaseTime       mStopTime        startTime     mStopTime    mCurrTime

		if (mStopped)
		{
			return (float)(((mStopTime - mPausedTime) - mBaseTime) * mSecondsPerCount);
		}

		// The distance mCurrTime - mBaseTime includes paused time,
		// which we do not want to count.  To correct this, we can subtract 
		// the paused time from mCurrTime:  
		//
		//  (mCurrTime - mPausedTime) - mBaseTime 
		//
		//                     |<--paused time-->|
		// ----*---------------*-----------------*------------*------> time
		//  mBaseTime       mStopTime        startTime     mCurrTime

		else
		{
			return (float)(((mCurrTime - mPausedTime) - mBaseTime) * mSecondsPerCount);
		}
	}
	void Start()//ȡ����ͣʱ����
	{
		__int64 startTime;
		QueryPerformanceCounter((LARGE_INTEGER*)&startTime);


		// Accumulate the time elapsed between stop and start pairs.
		//
		//                     |<-------d------->|
		// ----*---------------*-----------------*------------> time
		//  mBaseTime       mStopTime        startTime     

		if (mStopped)
		{
			mPausedTime += (startTime - mStopTime);

			mPrevTime = startTime;
			mStopTime = 0;
			mStopped = false;
		}
	}
	void Stop()//��ͣʱ����
	{
		if (!mStopped)
		{
			__int64 currTime;
			QueryPerformanceCounter((LARGE_INTEGER*)&currTime);

			mStopTime = currTime;
			mStopped = true;
		}
	}
private:
	double mSecondsPerCount;
	double mDeltaTime;
	__int64 mBaseTime;
	__int64 mPausedTime;
	__int64 mStopTime;
	__int64 mPrevTime;
	__int64 mCurrTime;
	bool mStopped;
};
GameTimer theTimer;
void CalculateFPS()
{
	static int frameCnt = 0;
	static float timeElapsed = 0.0f;
	frameCnt++;
	if ((theTimer.TotalTime() - timeElapsed) >= 1.f)//1.0msˢ��һ��
	{
		float fps = (float)frameCnt;
		float mspf = 1000.0f / fps;

		wostringstream outs;
		outs.precision(6);
		outs
			<< L"total numberof ball:" << TotalNumberOfBall
			<< L"    FPS: " << fps << L"   "
			<< L"Frame Time:" << mspf << L"(ms)    "
			<< L"collsion number:" << Ball::collnumber
			<< L"    total collsion number:" << Ball::totalcollnumber;
		SetWindowText(hwnd, outs.str().c_str());
		frameCnt = 0;
		timeElapsed += 1.0f;
	}
}
bool CollisionTest(Ball* target1, Ball* target2)
{
	return FALSE;
}
//����ѭ��
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_ACTIVATE:
	{
		if (LOWORD(wParam) == WA_INACTIVE)
		{
			theTimer.Stop();
			GameIsRun = false;
		}
		else
		{
			theTimer.Start();
			GameIsRun = true;
		}
	}
	break;
	case WM_PAINT:
	{
		ValidateRect(hwnd, nullptr);
	}
	break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_MOVE:
		//Render();
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);

	}
	return 0;
}
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)

{
	theTimer.Reset();
	///////////////////////////////////////////////////////init///////////////////////////////////////////////
	hwnd = CreateMyWindow(hInstance, WndProc, nCmdShow);
	//init input
	LPDIRECTINPUT8 DirectInput = nullptr;
	DirectInput8Create(hInstance,
		DIRECTINPUT_HEADER_VERSION, IID_IDirectInput8,
		(void**)&DirectInput, NULL);
	LPDIRECTINPUTDEVICE8 KeyboardsDevice = nullptr;
	DirectInput->CreateDevice(GUID_SysKeyboard, &KeyboardsDevice, NULL);
	KeyboardsDevice->SetDataFormat(&c_dfDIKeyboard);
	KeyboardsDevice->SetCooperativeLevel(hwnd, DISCL_FOREGROUND);
	char KeyStateBuffer[256] = { 0 };
	//init render target
	ID2D1Factory* Direct2dFactory;
	ID2D1HwndRenderTarget* RenderTarget;
	RECT rc;
	D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &Direct2dFactory);

	GetClientRect(hwnd, &rc);
	D2D1_SIZE_U size = D2D1::SizeU(
		rc.right - rc.left,
		rc.bottom - rc.top
	);
	Direct2dFactory->CreateHwndRenderTarget(
		D2D1::RenderTargetProperties(),
		D2D1::HwndRenderTargetProperties(hwnd, size),
		&RenderTarget
	);
	ID2D1SolidColorBrush* brush1;
	ID2D1SolidColorBrush* brush2;
	RenderTarget->CreateSolidColorBrush(D2D1::ColorF(0x9AC0CD), &brush1);
	RenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Enum::White), &brush2);
	//game init
	vector<Ball*> spriteList;
	Ball* player = new Ball(width / 2, height / 2);
	player->setmaxspeed(100);

	////////////////////////////////////////////////////////////////////////////////////////////////////////
	float left = 0 + 100 / 2;
	float right = width - 100 / 2;
	float top = 0 + 100 / 2;
	float bottom = height - 100 / 2;
	//create enemy
	int enemy_width = 3;
	int enemy_height = 15;
	float time = 1;
	static float time_interval = 1;
	int x = 0;
	int count = 0;
	f_tree gametree;
	gametree.setmax(balltreemax);
	gametree.setrootrec(0, 0, realwidth, realheight);
	vector<Ball*>::iterator i;
	bool flag = false;
	MSG msg;
	while (true)
	{

		if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
			{
				break;
			}
			DispatchMessage(&msg);
		}
		if (GameIsRun)
		{
			CalculateFPS();
			/*
			memset(KeyStateBuffer, 0, sizeof(KeyStateBuffer));

			while (true)
			{
				HRESULT hr;
				KeyboardsDevice->Poll();              // ��ѯ�豸
				KeyboardsDevice->Acquire();          // ��ȡ�豸�Ŀ���Ȩ
				if (SUCCEEDED(hr = KeyboardsDevice->GetDeviceState(sizeof(KeyStateBuffer), KeyStateBuffer))) break;
				if (hr != DIERR_INPUTLOST || hr != DIERR_NOTACQUIRED) return FALSE;
				if (FAILED(KeyboardsDevice->Acquire())) return FALSE;
			}
			*/
			//update
			theTimer.Tick();
			//player logic
			point temp = player->getposition();
			Magnitude tv = player->getvelocity();
			if (KeyStateBuffer[DIK_UPARROW] & 0x80) { player->setvelocity(tv.getx(), tv.gety() - theTimer.DeltaTime()); }
			if (KeyStateBuffer[DIK_DOWNARROW] & 0x80) { player->setvelocity(tv.getx(), tv.gety() + theTimer.DeltaTime()); }
			if (KeyStateBuffer[DIK_LEFTARROW] & 0x80) { player->setvelocity(tv.getx() - theTimer.DeltaTime(), tv.gety()); }
			if (KeyStateBuffer[DIK_RIGHTARROW] & 0x80) { player->setvelocity(tv.getx() + theTimer.DeltaTime(), tv.gety()); }
			player->move(theTimer.DeltaTime());


			if (temp.getx() < left) player->setpos(left, temp.gety());
			if (temp.getx() > right) player->setpos(right, temp.gety());
			if (temp.gety() < top)  player->setpos(temp.getx(), top);
			if (temp.gety() > bottom) player->setpos(temp.getx(), bottom);

			if (time_interval >= time)
			{
				time_interval = 0;
				x = enemy_create_number;
				count += enemy_create_number;
				while (x-- && count <= TotalNumberOfBall)
				{
					Ball* temp = new Ball();
					random_device rd;
					mt19937 mt(rd());
					uniform_int_distribution<> dis(0, 3);
					uniform_int_distribution<> dis1(0, realwidth);  //С�����ɷ�Χ
					uniform_int_distribution<> dis2(0, realheight);  //С�����ɷ�Χ
					uniform_int_distribution<> dis_real1(-10, 10);  //С���ٶȷ�Χ
					uniform_int_distribution<> dis_real2(-10, 0);//С���ٶȷ�Χ
					uniform_int_distribution<> dis_real3(0, 10);//С���ٶȷ�Χ
					switch (dis(mt))//���ɷ���
					{
					case 0: //��


						temp->setpos(dis(mt), 0);
						temp->setvelocity(Magnitude(dis_real1(mt), dis_real3(mt)));
						break;
					case 1: //��

						temp->setvelocity(Magnitude(dis_real1(mt), dis_real2(mt)));
						break;
					case 2: //��

						temp->setvelocity(Magnitude(dis_real3(mt), dis_real1(mt)));
						break;
					case 3: //��

						temp->setvelocity(Magnitude(dis_real2(mt), dis_real1(mt)));
						break;
					default:
						break;
					}
					temp->setpos(dis1(mt), dis2(mt));
					temp->setmaxspeed(100);
					spriteList.push_back(temp);
					gametree.insert(temp);

				}

			}
			else
			{
				time_interval += theTimer.DeltaTime();
			}

			//��ײ��⼰�䴦��
			if (!flag) {
				i = spriteList.begin();
				flag = true;
			}
			/*for (vector<Ball*>::iterator k = spriteList.begin(); k != spriteList.end();) {
				gametree.check(*k);
				k++;
			}*/
			Ball::collnumber = 0;
			gametree.check();
			Ball::boommm();
			gametree.clear();
			i = spriteList.begin();
			/*while (i != spriteList.end())
			{
				(*i)->action(theTimer.DeltaTime(), realwidth, realheight);
				//gametree.reinsert(*i, realwidth, realheight);
				(*i)->flag = 0;
				i++;
			}*/
			//#pragma omp    parallel
			for (int i = 0; i < spriteList.size(); i++)
			{
				spriteList[i]->action(theTimer.DeltaTime(), realwidth, realheight);
				spriteList[i]->flag = 0;
			}

			//#pragma omp barrier
			i = spriteList.begin();
			while (i != spriteList.end())
			{
				gametree.reinsert(*i, realwidth, realheight);
				i++;
			}
			//render
			RenderTarget->BeginDraw();
			RenderTarget->Clear();
			//draw player
			//draw enemy

			/*for (vector<Ball*>::iterator i = spriteList.begin(); i != spriteList.end(); i++)
			{
				Ball* temp = *i;
				if (temp->IsInside(width,height)) {
					RenderTarget->DrawEllipse
					(
						D2D1::Ellipse(D2D1::Point2F(temp->getposition().getx(), temp->getposition().gety()),
							0.5,
							0.5),
						brush2);
				};
			}*/

			for (int i = 0; i < spriteList.size(); i++)
			{
				Ball* temp = spriteList[i];
				if (temp->IsInside(width, height)) {
					RenderTarget->DrawEllipse
					(
						D2D1::Ellipse(D2D1::Point2F(temp->getposition().getx(), temp->getposition().gety()),
							0.5,
							0.5),
						brush2);
				};
			}

			RenderTarget->EndDraw();

		}
	}
}